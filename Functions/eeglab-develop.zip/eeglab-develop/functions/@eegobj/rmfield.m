function this = rmfield(this, vals);

    this.EEG = rmfield(this.EEG, vals);
    
