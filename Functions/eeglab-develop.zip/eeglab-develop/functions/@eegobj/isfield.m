function res = isfield(this, vals);

    res = isfield(struct(this(1).EEG), vals);
